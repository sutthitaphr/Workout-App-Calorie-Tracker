package com.example.workoutappcalorietracker.ui.Settings;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class OrderHistoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_order_history);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Order History");

    }
}
