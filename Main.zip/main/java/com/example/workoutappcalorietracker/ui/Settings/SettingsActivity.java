package com.example.workoutappcalorietracker.ui.Settings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_settings);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Settings");

        Button accDetailsButton = findViewById(R.id.btn_acc);
        Button orderHistoryButton = findViewById(R.id.btn_order_history);
        Button policyButton = findViewById(R.id.btn_policy);

        accDetailsButton.setOnClickListener(v -> openAccountDetailsActivity());

        orderHistoryButton.setOnClickListener(v -> openOrderHistoryActivity());

        policyButton.setOnClickListener(v -> openPrivacyPolicyActivity());
    }

    private void openPrivacyPolicyActivity() {
        Intent intent = new Intent(this, PrivacyPolicyActivity.class);
        startActivity(intent);
    }

    private void openOrderHistoryActivity() {
        Intent intent = new Intent(this, OrderHistoryActivity.class);
        startActivity(intent);
    }

    private void openAccountDetailsActivity() {
        Intent intent = new Intent(this, AccountDetailsActivity.class);
        startActivity(intent);
    }

}
