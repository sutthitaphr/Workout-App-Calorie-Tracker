package com.example.workoutappcalorietracker.ui.ShoppingPages;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class PurchaseMainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.purchase_main);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Purchase");

        Button buyButton = findViewById(R.id.btn_buy_now);
        Button buyButton2 = findViewById(R.id.btn_buy_now2);
        Button buyButton3 = findViewById(R.id.btn_buy_now3);

        buyButton.setOnClickListener(v -> openPurchasePaymentActivity());
        buyButton2.setOnClickListener(v -> openPurchasePaymentActivity());
        buyButton3.setOnClickListener(v -> openPurchasePaymentActivity());
    }

    private void openPurchasePaymentActivity() {
        Intent intent = new Intent(this, PurchasePaymentActivity.class);
        startActivity(intent);
    }
}
