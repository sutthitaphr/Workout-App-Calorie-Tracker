package com.example.workoutappcalorietracker.ui.ShoppingPages;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class PurchasePaymentActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.purchase_payment);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Purchase Payment");

        Button payButton = findViewById(R.id.btn_pay);

        payButton.setOnClickListener(v -> openPurchaseCofirmActivity());
    }

    private void openPurchaseCofirmActivity() {
        Intent intent = new Intent(this, PurchaseConfrimActivity.class);
        startActivity(intent);
    }
}
