package com.example.workoutappcalorietracker.ui.ShoppingPages;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class PurchaseConfrimActivity extends AppCompatActivity {
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.purchase_confirm);
            Objects.requireNonNull(getSupportActionBar()).setTitle("Purchase Payment Confirm");
        }
}
