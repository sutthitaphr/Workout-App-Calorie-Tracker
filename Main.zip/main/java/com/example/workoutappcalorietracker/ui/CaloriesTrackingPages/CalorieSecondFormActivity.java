package com.example.workoutappcalorietracker.ui.CaloriesTrackingPages;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;
import com.example.workoutappcalorietracker.ui.DietaryPages.DietaryFormActivity;

import java.util.Objects;

public class CalorieSecondFormActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calroie_second_form);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Calorie Form");

        Button nextButton = findViewById(R.id.btn_next2);

        nextButton.setOnClickListener(v -> openDietaryFormActivity());
    }
    private void openDietaryFormActivity() {
        Intent intent = new Intent(this, DietaryFormActivity.class);
        startActivity(intent);
    }
}
