package com.example.workoutappcalorietracker.ui.CaloriesTrackingPages;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class CalorieMainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner spinner;
    private RadioButton rdButton;
    private RadioGroup rdGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calrorie_main);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Calorie Tracking");
        spinner = findViewById(R.id.spinner);
        rdGroup = findViewById(R.id.radioGroup);

        Button calButton = findViewById(R.id.btn_calculator);
        calButton.setOnClickListener(v -> openCalorieResultActivity());

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.Exercises, android.R.layout.simple_spinner_dropdown_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(this);

    }

    private void openCalorieResultActivity() {
        Intent intent = new Intent(this, CalorieResultActivity.class);
        startActivity(intent);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String level = adapterView.getItemAtPosition(i).toString();
        Toast.makeText(getApplicationContext(), level, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void checkButton(View v) {
        int radioBtnId = rdGroup.getCheckedRadioButtonId();
        rdButton = findViewById(radioBtnId);
    }
}
