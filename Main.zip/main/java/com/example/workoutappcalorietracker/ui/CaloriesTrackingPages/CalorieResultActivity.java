package com.example.workoutappcalorietracker.ui.CaloriesTrackingPages;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class CalorieResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calorie_result);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Calorie Result");
    }
}
