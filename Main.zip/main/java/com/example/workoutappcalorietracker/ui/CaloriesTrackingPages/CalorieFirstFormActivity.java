package com.example.workoutappcalorietracker.ui.CaloriesTrackingPages;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class CalorieFirstFormActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calroie_first_form);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Calorie Form");

        Button nextButton = findViewById(R.id.btn_next1);

        nextButton.setOnClickListener(v -> openCalorieSecondFormActivity());
    }
    private void openCalorieSecondFormActivity() {
        Intent intent = new Intent(this, CalorieSecondFormActivity.class);
        startActivity(intent);
    }
}
