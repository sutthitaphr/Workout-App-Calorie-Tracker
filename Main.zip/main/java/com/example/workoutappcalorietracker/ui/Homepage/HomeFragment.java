package com.example.workoutappcalorietracker.ui.Homepage;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;
import com.example.workoutappcalorietracker.ui.CaloriesTrackingPages.CalorieMainActivity;
import com.example.workoutappcalorietracker.ui.DietaryPages.DietaryMainActivity;
import com.example.workoutappcalorietracker.ui.ShoppingPages.PurchaseMainActivity;

import java.util.Objects;

public class HomeFragment extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_home);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Homepage");

        Button trackingCalButton = findViewById(R.id.btn_tracking_cal);
        Button dietaryButton = findViewById(R.id.btn_dietary);
        Button shoppingButton = findViewById(R.id.btn_shopping);

        trackingCalButton.setOnClickListener(v -> openCalorieMainActivity());

        dietaryButton.setOnClickListener(v -> openDietaryMainActivity());

        shoppingButton.setOnClickListener(v -> openShoppingMainActivity());
    }

    private void openCalorieMainActivity() {
        Intent intent = new Intent(this, CalorieMainActivity.class);
        startActivity(intent);
    }

    private void openDietaryMainActivity() {
        Intent intent = new Intent(this, DietaryMainActivity.class);
        startActivity(intent);
    }

    private void openShoppingMainActivity() {
        Intent intent = new Intent(this, PurchaseMainActivity.class);
        startActivity(intent);
    }
}