package com.example.workoutappcalorietracker.ui.SignUpPages;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

public class SignInActivity extends AppCompatActivity {
    private Button loginButton;
    private Button signupButton;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_sign_in);
        getSupportActionBar().setTitle("Sign In");

        loginButton = (Button) findViewById(R.id.btn_login);
        signupButton = (Button) findViewById(R.id.btn_sign_up);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLoginActivity();
            }

        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSignUpActivity();
            }
        });
    }

        private void openLoginActivity() {
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
        }

        private void openSignUpActivity() {
            Intent intent = new Intent(this, SignUpActivity.class);
            startActivity(intent);
        }
}
