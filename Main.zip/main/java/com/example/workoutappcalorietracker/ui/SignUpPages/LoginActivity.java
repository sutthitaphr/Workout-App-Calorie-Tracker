package com.example.workoutappcalorietracker.ui.SignUpPages;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;
import com.example.workoutappcalorietracker.ui.Homepage.HomeFragment;
import com.google.firebase.auth.FirebaseAuth;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    private EditText uEmail;
    private EditText uPassword;
    private Button uLoginButton;
    ProgressBar progressBarLogin;

    //Part of Firebase Class
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_login);
        getSupportActionBar().setTitle("Login");

        uEmail = findViewById(R.id.email);
        uPassword = findViewById(R.id.password);
        uLoginButton = findViewById(R.id.btn_login_acc);
        progressBarLogin = findViewById(R.id.progress_bar);

        fAuth = FirebaseAuth.getInstance();

        uLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = uEmail.getText().toString();
                String password = uPassword.getText().toString();

                // Make fields required
                if (TextUtils.isEmpty(email)) {
                    uEmail.setError("Invalid Email!");
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    uPassword.setError("Invalid Password!");
                    return;
                }

                // Display a progress bar to the user know that the app is Loading
                progressBarLogin.setVisibility(View.VISIBLE);

                //Authenticate the User
               fAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    //If login form was successful or not
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            //If Login is successful, send user to Home Page
                            startActivity(new Intent(getApplicationContext(), HomeFragment.class));
                        } else {
                            Toast.makeText(LoginActivity.this, "Something went wrong!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

    }
}
