package com.example.workoutappcalorietracker.ui.SignUpPages;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class SignUpActivity extends AppCompatActivity {

    //Variables
    private EditText uFirstName;
    private EditText uLastName;
    private EditText uEmail;
    private EditText uPassword;
    private EditText uConfirmPassword;
    private Button uSignUpButton;
    ProgressBar progressBar;

    //Part of Firebase authentication
    /*FirebaseAuth fAuth;*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_sign_up);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Sign Up");

        //Objects from GUI
        uFirstName = findViewById(R.id.first_name);
        uLastName = findViewById(R.id.last_name);
        uEmail = findViewById(R.id.sign_up_email);
        uPassword = findViewById(R.id.sign_up_password);
        uConfirmPassword = findViewById(R.id.confirm_password);
        uSignUpButton = findViewById(R.id.btn_sign_up_acc);

        //Part of Firebase authentication
        /*fAuth = FirebaseAuth.getInstance();

        //Check if user is already logged in
         if(fAuth.getCurrentUser() != null){
         startActivity(new Intent(getApplicationContext(), HomeFragment.class));
         finish();
         }*/

        uSignUpButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String firstName = uFirstName.getText().toString();
                String lastName = uLastName.getText().toString();
                String email = uEmail.getText().toString();
                String password = uPassword.getText().toString();
                String confirmPassword = uConfirmPassword.getText().toString();

                // Make fields required
                if (TextUtils.isEmpty(firstName)) {
                    uFirstName.setError("First Name is Required!");
                    return;
                }

                if (TextUtils.isEmpty(lastName)) {
                    uLastName.setError("Last Name is Required!");
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    uEmail.setError("Invalid Email!");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    uPassword.setError("Invalid Password!");
                    return;
                }
                if (password.length() < 6) {
                    uPassword.setError("Password must have at least 6 characters");
                }
                if (TextUtils.isEmpty(confirmPassword)) {
                    uConfirmPassword.setError("Please confirm your Password");
                    return;
                }

                //Sign Up in Firebase
              /*  fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    //Check if sign up form was successful or not
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            //If User account is created, send user to the Home Page
                            startActivity(new Intent(getApplicationContext(), HomeFragment.class));
                        }else {
                            Toast.makeText(SignUpActivity.this, "Something went wrong!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }*/
            }
        });
    }
}