package com.example.workoutappcalorietracker.ui.LogOutPage;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;
import com.example.workoutappcalorietracker.ui.Homepage.HomeFragment;

import java.util.Objects;

public class LogOutActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_log_out);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Log Out");

        Button nextButton = findViewById(R.id.btn_logout);

        nextButton.setOnClickListener(v -> openHomeFragment());
    }
    private void openHomeFragment() {
        Intent intent = new Intent(this, HomeFragment.class);
        startActivity(intent);
    }
}
