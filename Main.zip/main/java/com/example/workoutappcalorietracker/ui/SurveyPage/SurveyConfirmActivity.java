package com.example.workoutappcalorietracker.ui.SurveyPage;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class SurveyConfirmActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_survey_confirm);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Survey Confirm");

    }
}
