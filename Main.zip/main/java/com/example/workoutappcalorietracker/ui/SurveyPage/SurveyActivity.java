package com.example.workoutappcalorietracker.ui.SurveyPage;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;


public class SurveyActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_survey);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Survey");

        Button nextButton = findViewById(R.id.btn_submit);

        nextButton.setOnClickListener(v -> openSurveyConfirmActivity());
    }

    private void openSurveyConfirmActivity() {
        Intent intent = new Intent(this, SurveyConfirmActivity.class);
        startActivity(intent);
    }


}