package com.example.workoutappcalorietracker.ui.DietaryPages;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;
import com.example.workoutappcalorietracker.ui.Homepage.HomeFragment;

import java.util.Objects;

public class DietaryFormActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dietary_form);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Dietary Form");

        Button nextButton = findViewById(R.id.btn_next3);

        nextButton.setOnClickListener(v -> openHomeFragment());
    }
    private void openHomeFragment() {
        Intent intent = new Intent(this, HomeFragment.class);
        startActivity(intent);
    }
}
