package com.example.workoutappcalorietracker.ui.DietaryPages;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutappcalorietracker.R;

import java.util.Objects;

public class DietaryMainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dietary_main);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Dietary");
    }
}
